﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TreasureHunt.Website.Controllers
{
    public class CompleteController : Controller
    {
        //
        // GET: /Complete/

        public ActionResult Index()
        {
            return View();
        }

    }
}
